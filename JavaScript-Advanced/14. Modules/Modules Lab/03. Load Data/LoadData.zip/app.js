let loadData = require('./03. Load Data');

result.sort = loadData.sort;
result.filter = loadData.filter;