let Employee = require('./Employee');
let Junior = require('./Junior');
let Senior = require('./Senior');
let Manager = require('./Manager');

result.Employee = Employee;
result.Junior = Junior;
result.Senior = Senior;
result.Manager = Manager;