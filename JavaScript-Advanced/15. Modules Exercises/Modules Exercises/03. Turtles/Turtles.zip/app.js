let Turtle = require('./Turtle');
let GalapagosTurtle = require('./GalapagosTurtle');
let WaterTurtle = require('./WaterTurtle');
let EvkodianTurtle = require('./EvkodianTurtle');
let NinjaTurtle = require('./NinjaTurtle');

result.Turtle = Turtle;
result.GalapagosTurtle = GalapagosTurtle;
result.WaterTurtle = WaterTurtle;
result.EvkodianTurtle = EvkodianTurtle;
result.NinjaTurtle = NinjaTurtle;